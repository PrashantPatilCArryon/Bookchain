<? ob_start(); ?>
<?php
session_start();
if ($_REQUEST['logout'] == "true")
{
    if(ISSET($_SESSION['username']))
    {
    UNSET($_SESSION['username']);
    }
}
header("location: index.php");
session_destroy();
?>
<? ob_flush(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Search Box Example 2 - default placeholder text gets cleared on click</title>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW" />
<!-- JAVASCRIPT to clear search text when the field is clicked -->
<script type="text/javascript">
window.onload = function(){ 
	//Get submit button
	var submitbutton = document.getElementById("tfq");
	//Add listener to submit button
	if(submitbutton.addEventListener){
		submitbutton.addEventListener("click", function() {
			if (submitbutton.value == 'Search by book name' ){//Customize this text string to whatever you want
				submitbutton.value = '';
			
			}
		});
	}
	
	var submitbutton1 = document.getElementById("tfq1");
	//Add listener to submit button
	if(submitbutton1.addEventListener){
		submitbutton1.addEventListener("click", function() {
			if (submitbutton1.value == 'Search by Author' ){//Customize this text string to whatever you want
				submitbutton1.value = '';
			
			}
		});
	}
	
	
	var submitbutton2 = document.getElementById("city");
	//Add listener to submit button
	if(submitbutton2.addEventListener){
		submitbutton2.addEventListener("click", function() {
			if (submitbutton2.value == 'Your Location' ){//Customize this text string to whatever you want
				submitbutton2.value = '';
			
			}
		});
	}
	
	var submitbutton3 = document.getElementById("clg");
	//Add listener to submit button
	if(submitbutton3.addEventListener){
		submitbutton3.addEventListener("click", function() {
			if (submitbutton3.value == 'Your College' ){//Customize this text string to whatever you want
				submitbutton3.value = '';
			
			}
		});
	}
	
	
	
}
</script>
<!-- CSS styles for standard search box with placeholder text-->
<style type="text/css">
	#tfheader{
		background-color:#c3dfef;
		width:auto;
		display:block;
		float:right;
		font-size:18px;
		font-family: Arial, Helvetica, sans-serif;
	}
	#tfnewsearch{
		float:right;
		padding:10px;
	}
	.tftextinput2,#branch{
		margin: 0;
		padding: 5px 15px;
		font-family: Arial, Helvetica, sans-serif;
		font-size:14px;
		color:#666;
		border:1px solid #0076a3; 
		border-radius: 5px ;
		
	}
	.tfbutton2 {
		margin: 0;
		padding: 0;
		width:30px;
		height:30px;
		font-family: Arial, Helvetica, sans-serif;
		font-size:14px;
		font-weight:bold;
		outline: none;
		cursor: pointer;
		text-align: center;
		text-decoration: none;
		color: #ffffff;
		border: solid 1px #0076a3;
		border-radius: 5px 5px;
		
		background: #438db8 url('tf-search-icon.png');
	}
	
	
	
	.tfbutton2:hover {
		text-decoration: none;
		
	}
	/* Fixes submit button height problem in Firefox */
	.tfbutton2::-moz-focus-inner {
	  border: 0;
	}
	
	.tfclear{
		clear:both;
	}
</style>
</head>
<body>
	<!-- HTML for SEARCH BAR -->
	<div id="tfheader">
		<form id="tfnewsearch" method="get" action="booksearch.php">
		<center>
		
		<br><br>
			
		        Book Name: <input type="text" id="tfq" class="tftextinput2" name="sn" size="21" maxlength="120" value="">  <br> <br>
				Author Name:<input type="text" id="tfq1" class="tftextinput2" name="sa" size="21" maxlength="120" value=""> <br><br>
				<br>
				
				Location:
				<input type="text" name="city" class="tftextinput2" id="city" list="cities" value="" >
                                                   <datalist id="cities"> 
                                <option value="Mumbai">
                                <option value="Bandra">
                                <option value="Sion">
                                <option value="Bhayandar">
                                <option value="Virar">
                                <option value="Matunga">
                                <option value="Ghatkopar">
                                <option value="Vikroli">
                                <option value="Kurla">
                                <option value="Panvel">
                                <option value="Kharghar">
                                <option value="Mankhurda">
                                <option value="Vasai">
                                <option value="Borivali">
                                <option value="Vashi">
							</datalist>
							<br><br>
							&nbsp 
							
							   
							   OR &nbsp <br>
							   <br>
				College:

				<input type="text" class="tftextinput2" name="clg" id="clg" list="clgs" value="" >
                                                   <datalist id="clgs"> 
                                <option value="Dadar">
                                <option value="Bandra">
                                <option value="Sion">
                                <option value="Bhayandar">
                                <option value="Virar">
                                <option value="Matunga">
                                <option value="Ghatkopar">
                                <option value="Vikroli">
                                <option value="Kurla">
                                <option value="Panvel">
                                <option value="Kharghar">
                                <option value="Mankhurda">
                                <option value="Vasai">
                                <option value="Borivali">
                                <option value="Vashi">
							</datalist>
				<br><br>
				
				<input type="submit" value="Search " class="tfbutton2"><br>
		</center>	
		
				
		</form>
		
		
		
		
		
		
		
		
		<div class="tfclear"></div>
	</div>
	
<!-- The search bar articles can be found on these two pages:
http://www.textfixer.com/tutorials/html-search-box.php
http://www.textfixer.com/tutorials/search-box-examples.php
-->

	
</body>
</html>

<?php ob_start(); session_start(); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<title>Send Mail</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
	<meta charset="utf-8">
	<link rel="icon" href="img/favicon.png" type="image/x-icon">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon" />
	<meta name="description" content="Your description">
	<meta name="keywords" content="Your keywords">
	<meta name="author" content="Your name">
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/responsive.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/superfish.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	    
	<script type="text/javascript">if($(window).width()>1024){document.write("<"+"script src='js/jquery.preloader.js'></"+"script>");}	</script>
	<script>		
		 jQuery(window).load(function() {	
		 $x = $(window).width();		
	if($x > 1024)
	{			
	jQuery("#content .row").preloader();}	
	
	jQuery(".list-blog li:last-child").addClass("last"); 
	jQuery(".list li:last-child").addClass("last"); 

	
    jQuery('.spinner').animate({'opacity':0},1000,'easeOutCubic',function (){jQuery(this).css('display','none')});	
  		  }); 
					
	</script>

	<!--[if lt IE 8]>
  		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
 	<![endif]-->
	<!--[if (gt IE 9)|!(IE)]><!-->
	<!--<![endif]-->
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>    
    <link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400' rel='stylesheet' type='text/css'>
  <![endif]-->
	</head>

	<body>
<div class="spinner"></div>
<!--============================== header =================================-->
<header>
      <?php include "header.php";?>
    </header>
<div class="bg-content"> 
<br/>      
  <!--============================== content =================================-->      

<div class="container">
          <div class="row">
        <article class="span8">
         <div class="inner-1">         
          <ul class="list-blog">
            <div class="container">
            <!-- Codrops top bar -->
           
            <section>				
                <div id="container_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
           
                    <div id="wrapper">
                        <div id="login" class="animate form">
                            

<?php
include("connection.php");
$receiver = $_GET['email'];
$bookid = $_GET['bookid'];
$q = mysql_query("select * from books where bookid='".$bookid."';");
$r = mysql_fetch_array($q);
$query = mysql_query("select * from users where userid='".$_SESSION['userid']."';");
$res = mysql_fetch_array($query);
$sender=$res['email'];
$cont =$sender." wants to buy your book <br>book details are:</br> Book name : ".$r['name']."</br>Author : " .$r['author']."</br>Publication : ".$r['publication']."<br>Price : ".$r['price'];
//echo $cont;
if( mail($receiver, "Activate Account!", $cont, "From: admin@trialofbookschain.comuv.com") )
{
   echo '<br/><b>Your Email is sent to the advertiser!!</b>';
}
?>
  <br/><br/><br/><br/>
                        </div>

                       
						
                    </div>
                </div>  
				
            </section>
        </div>
                                  
          </ul>
          </div>  
        </article>
       
      </div>
     </div>
  </div>

 </div>

<!--============================== footer =================================-->
<footer>
     <?php include "footer.php";?>
    </footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
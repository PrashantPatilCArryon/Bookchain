<h3>Advertisements</h3>
              <ul class="list-photo">
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img6.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img7.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img8.jpg " alt="" /></a></li>
            <li class="last"><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img9.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img10.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img11.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img12.jpg " alt="" /></a></li>
            <li class="last"><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img13.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img14.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img15.jpg " alt="" /></a></li>
            <li><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img16.jpg " alt="" /></a></li>
            <li class="last"><a href="img/image-blank.png" class="magnifier" ><img src="img/page1-img17.jpg " alt="" /></a></li>
          </ul>
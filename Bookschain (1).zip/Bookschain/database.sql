CREATE TABLE IF NOT EXISTS `books` (
  `bookid` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `author` varchar(40) NOT NULL,
  `category` varchar(30) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `price` int(10) NOT NULL,
  `searchtags` varchar(50) DEFAULT NULL,
  `publication` varchar(25) DEFAULT NULL,
  `quality` int(1) DEFAULT NULL,
  `usedfor` int(1) DEFAULT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;


CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobileno` varchar(10) NOT NULL,
  `city` varchar(30) NOT NULL,
  `area` varchar(15) NOT NULL,
  `college` varchar(30) NOT NULL,
  `branch` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;
